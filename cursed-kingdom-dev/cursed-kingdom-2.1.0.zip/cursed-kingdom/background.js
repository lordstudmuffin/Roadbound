/* Cursed Kingdom: reload helper for an unpacked install.
 * When the files in the extension folder change (build.txt differs from the copy that was loaded),
 * the extension reloads itself the next time any page starts, so nobody has to press the reload
 * arrow in chrome://extensions. It reads only the extension's own files. No network, no page access.
 */
const api = globalThis.chrome || globalThis.browser;
const stamp = () => fetch(api.runtime.getURL('build.txt'), { cache: 'no-store' }).then((r) => (r.ok ? r.text() : '')).then((t) => t.trim()).catch(() => '');
api.runtime.onInstalled.addListener(() => { stamp().then((s) => api.storage.local.set({ loadedStamp: s })); });
let last = 0;
api.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'cf-ping' || Date.now() - last < 4000) return;
  last = Date.now();
  Promise.all([stamp(), api.storage.local.get({ loadedStamp: null })]).then(([disk, got]) => {
    if (got.loadedStamp === null) return api.storage.local.set({ loadedStamp: disk });
    if (disk && disk !== got.loadedStamp) api.runtime.reload();
  }).catch(() => {});
});
