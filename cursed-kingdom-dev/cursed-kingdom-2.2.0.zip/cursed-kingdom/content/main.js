/* Cursed Kingdom: content script (top frame only).
 *
 * Hard rules this file is built around:
 *  1. Visual and label changes only. Page text nodes, numbers, form fields, values and
 *     event handlers are never written to. Labels are "renamed" by painting themed
 *     wording over an untouched original (see content.css).
 *  2. Protected pages (banking, payment, checkout, login) are left completely alone,
 *     and the check errs toward protecting.
 *  3. Work caused by page changes is batched into idle time with a strict budget.
 */
(() => {
  'use strict';
  if (window.top !== window) return;
  const ct = document.contentType || '';
  if (ct !== 'text/html' && ct !== 'application/xhtml+xml') return;

  const CF = globalThis.__CF;
  const api = globalThis.chrome || globalThis.browser;
  if (!CF || !api || !api.storage) return;

  const DEFAULTS = {
    enabled: true, intensity: 60, labels: true, fog: false, events: true,
    sound: false, soundKind: 'both', volume: 35, flip: true, fonts: true, scene: true, blocklist: [], darken: {}
  };

  const html = document.documentElement;
  const host = location.hostname.toLowerCase();
  const theme = CF.themeFor(host);
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');

  let settings = Object.assign({}, DEFAULTS);
  let active = false;
  let reason = 'starting';
  let stickyReason = null;      // set while a visible password / card field is on the page
  let mode = null;              // 'inv' (light page, colour-flipped) or 'dark' (already dark, left as is)
  let graded = false;           // dark page that gets the warm grade (false when the person turned darkening off)
  let level = 2;
  let lastHref = location.href;
  let dead = false;             // extension was reloaded or removed underneath us
  let visitCounted = false;

  const idle = window.requestIdleCallback
    ? (fn) => window.requestIdleCallback(fn, { timeout: 800 })
    : (fn) => setTimeout(() => fn({ timeRemaining: () => 8 }), 60);

  function safe(fn) {
    try { return fn(); } catch (e) {
      if (String(e && e.message).includes('Extension context invalidated')) { dead = true; teardown(); }
      return undefined;
    }
  }

  /* ------------------------------------------------------------------ protected pages */

  function domSensitive(rootNode) {
    try {
      return CF.sensitive.domHit(rootNode);
    } catch (e) { return true; } // if the check itself fails, protect
  }

  function blocklisted() {
    const h = host.replace(/^www\./, '');
    return (settings.blocklist || []).some((e) => CF.sensitive.hostMatches(h, String(e).toLowerCase().replace(/^www\./, '')));
  }

  let clearTicks = 0;
  function sensitiveNow() {
    if (!document.body) return false;
    if (domSensitive(document)) return true;
    for (const sr of seenRoots) if (sr.isConnected && domSensitive(sr)) return true;
    return false;
  }
  function tripSensitive(why) {
    stickyReason = why;
    evaluate();
  }

  function evaluate() {
    if (dead) return;
    let r = null;
    if (!settings.enabled) r = 'off';
    else if (blocklisted()) r = 'blocklist';
    else if (stickyReason) r = stickyReason;
    else {
      const u = CF.sensitive.urlReason(location);
      if (u) r = 'protected:' + u;
      else if (document.body && domSensitive(document)) { stickyReason = 'protected:password-or-card-field'; r = stickyReason; }
    }
    reason = r;
    if (r) { if (active) teardown(); active = false; }
    else { active = true; apply(); }
    watch(!!settings.enabled && !blocklisted() && !stickyReason);
  }

  /* ------------------------------------------------------------------ colour helpers */

  // Colour maps are affine: [m (3x3, row-major), o (offset)] on 0..1 rgb. These mirror the CSS filter
  // functions in content.css, so we can ask "what must a colour be BEFORE the page filter to END UP as X".
  const SEPIA = [0.12, 0.34, 0.5];
  const I3 = [1, 0, 0, 0, 1, 0, 0, 0, 1];
  const then = (A, B) => {     // apply A, then B
    const m = [], o = [];
    for (let r = 0; r < 3; r++) {
      for (let c = 0; c < 3; c++) m[r * 3 + c] = B[0][r * 3] * A[0][c] + B[0][r * 3 + 1] * A[0][3 + c] + B[0][r * 3 + 2] * A[0][6 + c];
      o[r] = B[0][r * 3] * A[1][0] + B[0][r * 3 + 1] * A[1][1] + B[0][r * 3 + 2] * A[1][2] + B[1][r];
    }
    return [m, o];
  };
  const F_FLIP = [[0.574, -1.43, -0.144, -0.426, -0.43, -0.144, -0.426, -1.43, 0.856], [1, 1, 1]];   // invert(1) hue-rotate(180deg)
  const fContrast = (c) => [I3.map((v) => v * c), [(1 - c) / 2, (1 - c) / 2, (1 - c) / 2]];
  const fBright = (b) => [I3.map((v) => v * b), [0, 0, 0]];
  const fSepia = (a) => {
    const S = [0.393, 0.769, 0.189, 0.349, 0.686, 0.168, 0.272, 0.534, 0.131];
    return [S.map((v, i) => v * a + I3[i] * (1 - a)), [0, 0, 0]];
  };
  function invertMap(M) {
    const [a, b, c, d, e, f, g, h, i] = M[0];
    const det = a * (e * i - f * h) - b * (d * i - f * g) + c * (d * h - e * g);
    const n = [(e * i - f * h), (c * h - b * i), (b * f - c * e), (f * g - d * i), (a * i - c * g), (c * d - a * f), (d * h - e * g), (b * g - a * h), (a * e - b * d)].map((v) => v / det);
    return (rgb) => {
      const x = rgb[0] / 255 - M[1][0], y = rgb[1] / 255 - M[1][1], z = rgb[2] / 255 - M[1][2];
      const q = (v) => Math.max(0, Math.min(255, Math.round(v * 255)));
      return [q(n[0] * x + n[1] * y + n[2] * z), q(n[3] * x + n[4] * y + n[5] * z), q(n[6] * x + n[7] * y + n[8] * z)];
    };
  }
  // preRoot: for things drawn straight on the page (and inside [cf-flip]). preKept: for things inside [cf-keep].
  let preRoot = (rgb) => rgb, preKept = (rgb) => rgb;
  function syncMaps() {
    const sep = fSepia(SEPIA[level - 1]);
    if (mode === 'inv') {
      const grade = then(then(fContrast(0.92), sep), fBright(1.08));
      preRoot = invertMap(then(F_FLIP, grade));
      preKept = invertMap(grade);
    } else if (graded) {
      preRoot = preKept = invertMap(sep);
    } else {
      preRoot = preKept = (rgb) => rgb;
    }
  }
  const rgba = (rgb, a) => 'rgba(' + rgb[0] + ',' + rgb[1] + ',' + rgb[2] + ',' + a + ')';
  const paint = (rgb, a) => rgba(preRoot(rgb), a);

  function parseColor(s) {
    const m = /rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s\/]+([\d.]+%?))?/.exec(s || '');
    if (!m) return null;
    let a = m[4] == null ? 1 : (m[4].endsWith('%') ? parseFloat(m[4]) / 100 : parseFloat(m[4]));
    const mx = Math.max(m[1], m[2], m[3]), mn = Math.min(m[1], m[2], m[3]);
    let hue = 0;
    if (mx > mn) {
      const r = +m[1], g = +m[2], b = +m[3], d = mx - mn;
      hue = mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
      hue *= 60;
    }
    return { l: (0.2126 * m[1] + 0.7152 * m[2] + 0.0722 * m[3]) / 255, a, sat: mx > 0 ? (mx - mn) / mx : 0, hue };
  }

  /* ------------------------------------------------------------------ dark detection */

  // What is actually painted behind the middle of the window? Many sites (YouTube, single-page apps)
  // paint their background on an inner element, so <body> alone tells nothing.
  function sampleBackdrop() {
    const w = window.innerWidth, h = window.innerHeight;
    if (!w || !h || !document.elementsFromPoint) return null;
    let dark = 0, light = 0;
    const pts = [[0.5, 0.5], [0.22, 0.3], [0.78, 0.3], [0.3, 0.78], [0.7, 0.78], [0.5, 0.14], [0.5, 0.9]];
    for (const [fx, fy] of pts) {
      let els;
      try { els = document.elementsFromPoint(w * fx, h * fy); } catch (e) { return null; }
      for (const el of els) {
        const nn = el.nodeName;
        if (nn === 'CF-VEIL') continue;
        if (nn === 'IMG' || nn === 'VIDEO' || nn === 'CANVAS' || nn === 'IFRAME' || nn === 'PICTURE' || nn === 'svg' || nn === 'EMBED' || nn === 'OBJECT') break;
        if (el.hasAttribute('cf-keep') || el.closest('[cf-keep]')) break;   // a dark bar on a light page says nothing about the page
        const cs = getComputedStyle(el);
        if (cs.backgroundImage && cs.backgroundImage !== 'none' && cs.backgroundImage.indexOf('url(') >= 0) break;
        const c = parseColor(cs.backgroundColor);
        if (c && c.a >= 0.95) { if (c.l < 0.4) dark++; else light++; break; }
      }
    }
    return { dark, light };
  }
  function detectMode() {
    const pref = (settings.darken || {})[host.replace(/^www\./, '')];
    if (pref === 'always') return { mode: 'inv', nobg: true, graded: false };
    if (pref === 'never' || (settings.flip === false && pref !== 'always')) return { mode: 'dark', nobg: false, graded: false };
    const b = document.body;
    let hb = parseColor(getComputedStyle(html).backgroundColor);
    // With cf-nobg set, a white root may be our own backstop rather than the page's colour; treat it as unpainted.
    if (html.hasAttribute('cf-nobg') && hb && hb.l > 0.99) hb = null;
    const bb = b ? parseColor(getComputedStyle(b).backgroundColor) : null;
    const tc = b ? parseColor(getComputedStyle(b).color) : null;
    const opaque = (c) => c && c.a > 0.5;
    const bg = opaque(bb) ? bb : (opaque(hb) ? hb : null);
    const s = b && document.readyState !== 'loading' && !document.hidden ? sampleBackdrop() : null;
    if (s && s.dark + s.light >= 4 && (s.dark === 0 || s.light === 0 || Math.max(s.dark, s.light) >= 2 * Math.min(s.dark, s.light))) {
      return s.dark > s.light ? { mode: 'dark', nobg: false, graded: true } : { mode: 'inv', nobg: !bg, graded: false };
    }
    if (bg) return { mode: bg.l < 0.4 ? 'dark' : 'inv', nobg: false, graded: bg.l < 0.4 };
    if (tc && tc.l > 0.75) return { mode: 'dark', nobg: false, graded: true };   // light text on an unpainted page: dark scheme
    return { mode: 'inv', nobg: true, graded: false };
  }

  /* ------------------------------------------------------------------ apply / teardown */

  function setAttr(el, k, v) { if (el.getAttribute(k) !== v) el.setAttribute(k, v); }

  function apply() {
    const lv = settings.intensity <= 33 ? 1 : settings.intensity <= 66 ? 2 : 3;
    const d = detectMode();
    const modeChanged = d.mode !== mode;
    const lookChanged = modeChanged || lv !== level || d.graded !== graded || settings.fonts !== lastFonts;
    mode = d.mode; level = lv; graded = d.graded; lastFonts = settings.fonts;
    syncMaps();
    setAttr(html, 'cf-on', '');
    if (fsSuspended) html.removeAttribute('cf-mode'); else setAttr(html, 'cf-mode', mode);
    setAttr(html, 'cf-level', String(level));
    if (graded && mode === 'dark') setAttr(html, 'cf-grade', ''); else html.removeAttribute('cf-grade');
    if (theme) setAttr(html, 'cf-theme', theme.id);
    if (d.nobg && mode === 'inv') setAttr(html, 'cf-nobg', ''); else html.removeAttribute('cf-nobg');
    if (level >= 2) loadFonts();
    if (modeChanged) clearKeep();
    if (lookChanged || !lookSheet) syncLookSheet();
    adoptDocSheet();
    if (document.body && document.readyState !== 'loading') {
      ensureVeil();
      paintVeil();
      if (mode === 'inv') scheduleKeep();
      if (!settings.labels) clearLabels();
      scheduleFullScan();
      countVisit();
      startTicker();
      syncSound();
    }
  }
  let lastFonts = true;

  // While a video (or canvas) is fullscreen, drop the colour flip entirely so playback runs through no filters at all.
  let fsSuspended = false;
  document.addEventListener('fullscreenchange', () => {
    const fs = document.fullscreenElement;
    let want = false;
    try { want = !!fs && (fs.matches('video,canvas') || !!fs.querySelector('video,canvas')); } catch (e) {}
    if (want === fsSuspended) return;
    fsSuspended = want;
    if (active && mode) { if (want) html.removeAttribute('cf-mode'); else setAttr(html, 'cf-mode', mode); syncLookSheet(); paintVeil(); }
  });

  function teardown() {
    for (const a of ['cf-on', 'cf-mode', 'cf-level', 'cf-theme', 'cf-nobg', 'cf-grade']) html.removeAttribute(a);
    mode = null;
    clearLabels();
    clearKeep();
    dropShadowSheets();
    if (veil) { veil.host.remove(); veil.tint.remove(); veil.scene.remove(); veil = null; }
    stopSound();
    queue.length = 0; walker = null; fullScanWanted = false;
  }

  /* ------------------------------------------------------------------ fonts */

  let fontsLoaded = false;
  function loadFonts() {
    if (fontsLoaded) return;
    fontsLoaded = true;
    safe(() => {
      const add = (name, file, desc) => {
        const f = new FontFace(name, 'url("' + api.runtime.getURL('fonts/' + file) + '") format("woff2")', Object.assign({ display: 'swap' }, desc || {}));
        document.fonts.add(f);
        f.load().catch(() => {});
      };
      add('CF Cinzel', 'cinzel.woff2', { weight: '400 900' });
      add('CF Pirata', 'pirata-one.woff2');
      add('CF Garamond', 'garamond.woff2', { weight: '400 800', style: 'normal', sizeAdjust: '116%' });
      add('CF Garamond', 'garamond-italic.woff2', { weight: '400 800', style: 'italic', sizeAdjust: '116%' });
      add('CF Fell', 'fell.woff2', { style: 'normal', sizeAdjust: '106%' });
      add('CF Fell', 'fell-italic.woff2', { style: 'italic', sizeAdjust: '106%' });
    });
  }

  /* ------------------------------------------------------------------ dark sections on light pages */

  // The root flip turns a dark bar, button or cookie banner on a light page into a glaring light one.
  // Those are found and "kept" (flipped back, so they show their own dark colours). A light box inside
  // a kept area (a search field in a dark header) is flipped once more so it does not glare either.
  let keepTimer = 0;
  function scheduleKeep() {
    clearTimeout(keepTimer);
    keepTimer = setTimeout(() => idle(scanKeep), 250);
  }
  const kept = new Map();      // element -> 'dark' | 'pic' | 'player'
  const flipped = new Set();
  const refusedKeep = new WeakSet();
  const KEEP_MAX = 500;
  // Would putting a filter on `el` change anything besides its colours? A filter makes the element a
  // stacking context and the anchor for position:fixed descendants. So it is only allowed when the
  // element is small enough to inspect, has no fixed descendants, hides nothing in shadow DOM, and
  // either has no z-indexed descendants or already is a stacking context. Anything else stays flipped.
  function filterIsHarmless(el) {
    if (el === document.body || el === html || el.shadowRoot) return false;
    const kids = el.getElementsByTagName('*');
    if (kids.length > 1500) return false;
    let layered = false, box = null;
    for (let q = 0; q < kids.length; q++) {
      const k = kids[q];
      if (k.shadowRoot) return false;
      const cs = getComputedStyle(k);
      if (cs.position === 'fixed') return false;
      if (cs.position !== 'static' && cs.zIndex !== 'auto') {
        // A layered part that is hidden (a menu waiting to drop down) or reaches outside the box could
        // end up behind later content once the box becomes its own layer. Parts that stay inside cannot.
        if (!box) box = el.getBoundingClientRect();
        const r = k.getClientRects().length ? k.getBoundingClientRect() : null;
        if (!r || r.left < box.left - 2 || r.top < box.top - 2 || r.right > box.right + 2 || r.bottom > box.bottom + 2) layered = true;
      }
    }
    if (!layered) return true;
    const cs = getComputedStyle(el);
    return (cs.position !== 'static' && cs.zIndex !== 'auto') || cs.position === 'fixed' || cs.position === 'sticky' ||
      parseFloat(cs.opacity) < 1 || cs.transform !== 'none' || cs.isolation === 'isolate' || /paint|strict|content/.test(cs.contain || '');
  }
  function closestAcross(el, sel) {
    for (let n = el; n; ) {
      const hit = n.closest(sel);
      if (hit) return hit;
      const r = n.getRootNode();
      n = r && r.host ? r.host : null;
    }
    return null;
  }
  const hasKeptAncestor = (el) => !!closestAcross(el, '[cf-keep]');
  function keep(el, kind, mark) {
    if (!el.isConnected || kept.size >= KEEP_MAX || refusedKeep.has(el) || hasKeptAncestor(el)) return false;
    if (!filterIsHarmless(el)) { refusedKeep.add(el); return false; }
    el.setAttribute('cf-keep', mark || '');
    kept.set(el, kind || 'dark');
    return true;
  }
  // Should this background stay as the site painted it rather than be flipped? Returns the mark to use:
  //   ''   a dark neutral box: shown in its own colours
  //   'bl' / 'bd'  a strong cool colour (blue, purple, green) with light / dark text: recast in bronze
  //   'wl' / 'wd'  a strong warm colour (red, orange, gold) with light / dark text: kept as it is
  function boxKind(c, cs) {
    const warmHue = c.hue <= 58 || c.hue >= 335;
    if (c.sat >= 0.5 && c.l <= (warmHue ? 0.7 : 0.8) && c.l >= 0.04) {
      const t = parseColor(cs.color);
      const lightText = !!t && t.l >= 0.6;
      if (c.l > 0.45 && !lightText && c.sat < 0.7) return null;
      return (warmHue ? 'w' : 'b') + (lightText ? 'l' : 'd');
    }
    return c.l <= 0.3 ? '' : null;
  }
  // The colour a gradient or picture background amounts to, or null when it cannot be told.
  function paintedColor(el, cs) {
    const c = parseColor(cs.backgroundColor);
    const img = cs.backgroundImage;
    if (!img || img === 'none') return c;
    if (img.indexOf('gradient(') >= 0 && img.indexOf('url(') < 0) {
      const stops = img.match(/rgba?\([^)]*\)/g);
      if (!stops || !stops.length) return c;
      let l = 0, a = 0, best = null;
      for (const st of stops) { const p = parseColor(st); if (!p) continue; l += p.l; a += p.a; if (!best || p.sat > best.sat) best = p; }
      if (!best) return c;
      return { l: l / stops.length, a: a / stops.length, sat: best.sat, hue: best.hue };
    }
    return c;
  }
  const NO_BOX = new Set(['B', 'I', 'EM', 'STRONG', 'U', 'S', 'SMALL', 'SUB', 'SUP', 'BR', 'WBR', 'IMG', 'PICTURE', 'SOURCE', 'PATH', 'HR',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'P', 'HEAD', 'META', 'LINK', 'TITLE', 'INPUT', 'TEXTAREA', 'SELECT']);
  function considerBox(el) {
    if (mode !== 'inv' || el === html || el === document.body) return;
    if (NO_BOX.has(el.nodeName)) return;
    if (el.hasAttribute('cf-keep') || el.hasAttribute('cf-flip') || el.hasAttribute('cf-tone') || refusedKeep.has(el)) return;
    const cs = getComputedStyle(el);
    const c = paintedColor(el, cs);
    const k = closestAcross(el, '[cf-keep]');
    if (!k) {
      const img = cs.backgroundImage;
      if (img && img.indexOf('url(') >= 0) {
        // A picture set from a stylesheet with light text over it (a hero banner): show it in its true colours.
        const t = parseColor(cs.color);
        if (!t || t.l < 0.7) return;
        const r = el.getBoundingClientRect();
        if (r.width >= 160 && r.height >= 90) keep(el, 'pic');
        return;
      }
      if (!c || c.a < 0.35) return;
      const kind = boxKind(c, cs);
      if (kind === null) return;
      const r = el.getBoundingClientRect();
      if (r.width < 20 || r.height < 14 || r.width * r.height < 700) return;
      // A see-through dark sheet only counts when it is a page-wide scrim behind a dialog.
      if (c.a < 0.9 && (kind !== '' || r.width < window.innerWidth * 0.8 || r.height < window.innerHeight * 0.8)) return;
      keep(el, 'dark', kind);
    } else {
      if (!c || kept.get(k) !== 'dark' || k.getAttribute('cf-keep') !== '' || c.a < 0.9 || flipped.size >= KEEP_MAX) return;
      if (closestAcross(el, '[cf-flip],[cf-tone]')) return;
      const kind = boxKind(c, cs);
      if (kind === 'bl' || kind === 'bd') {
        // a blue or purple button sitting inside a kept dark bar: recast in bronze where it stands
        const r = el.getBoundingClientRect();
        if (r.width < 20 || r.height < 14 || r.width * r.height < 700) return;
        if (!filterIsHarmless(el)) { refusedKeep.add(el); return; }
        el.setAttribute('cf-tone', kind[1]);
        flipped.add(el);
        return;
      }
      if (c.l < 0.62 || c.sat > 0.45) return;
      const r = el.getBoundingClientRect();
      if (r.width < 20 || r.height < 14 || r.width * r.height < 700) return;
      if (!filterIsHarmless(el)) { refusedKeep.add(el); return; }
      el.setAttribute('cf-flip', '');
      flipped.add(el);
    }
  }
  // Cheap pre-filter: bare elements with no class, id or inline style are almost never painted boxes.
  const BOX_TAGS = new Set(['BUTTON', 'HEADER', 'FOOTER', 'NAV', 'ASIDE', 'SECTION', 'TABLE', 'TR', 'TD', 'TH', 'DIALOG', 'FORM']);
  function boxWorthy(el) {
    const nn = el.nodeName;
    if (NO_BOX.has(nn)) return false;
    return BOX_TAGS.has(nn) || el.hasAttribute('class') || el.hasAttribute('id') || el.hasAttribute('style') || el.hasAttribute('bgcolor') || el.hasAttribute('role');
  }
  const boxQueue = [];
  let boxAt = 0, boxScheduled = false;
  function queueBox(el) {
    if (boxQueue.length - boxAt > 30000) return;      // a runaway feed: the oldest are checked first, the rest on the next full scan
    boxQueue.push(el);
    if (!boxScheduled) { boxScheduled = true; idle(boxSlice); }
  }
  function boxSlice(deadline) {
    boxScheduled = false;
    if (!active || mode !== 'inv') { boxQueue.length = 0; boxAt = 0; return; }
    const t0 = performance.now();
    while (boxAt < boxQueue.length) {
      const el = boxQueue[boxAt++];
      if (el.isConnected) considerBox(el);
      if ((boxAt & 31) === 0 && (performance.now() - t0 > 6 || (deadline.timeRemaining && deadline.timeRemaining() < 1))) break;
    }
    if (boxAt >= boxQueue.length) { boxQueue.length = 0; boxAt = 0; }
    else { boxScheduled = true; idle(boxSlice); }
  }
  // Sites restyle things after they appear (a chip becomes selected, a banner slides in). Look again now and then.
  const RESCAN = 'button,[role="button"],[role="tab"],[role="dialog"],[role="banner"],header,footer,nav,aside,section,dialog,' +
    'a[class],[class*="chip" i],[class*="banner" i],[class*="hero" i],[class*="badge" i],[class*="btn" i],[class*="button" i],[class*="cookie" i],[class*="consent" i]';
  function rescanBoxes() {
    if (boxAt < boxQueue.length) return;
    const all = document.querySelectorAll(RESCAN);
    const n = Math.min(all.length, 1500);
    for (let i = 0; i < n; i++) { const el = all[i]; if (!el.hasAttribute('cf-keep') && !refusedKeep.has(el)) queueBox(el); }
  }
  function scanKeep() {
    if (!active || mode !== 'inv' || !document.body) return;
    // A video player draws light controls over the picture; show the whole player in its true colours when that is safe.
    if (theme && theme.id === 'youtube') for (const el of document.querySelectorAll('#movie_player')) if (!el.hasAttribute('cf-keep')) keep(el, 'player');
    revalidateKeep();
  }
  // Sites restyle things (hover, theme switches). Drop marks that no longer fit; the scan re-adds what does.
  function revalidateKeep() {
    for (const [el, kind] of kept) {
      if (!el.isConnected) { kept.delete(el); continue; }
      if (kind !== 'dark') continue;
      const cs = getComputedStyle(el);
      const c = paintedColor(el, cs);
      const mark = el.getAttribute('cf-keep');
      const now = c && c.a >= 0.3 ? boxKind(c, cs) : null;
      // hover states wobble a colour a little; only a real change of family drops the mark
      if (now === null ? (!c || c.a < 0.3 || c.l > (mark === '' ? 0.5 : 0.8)) : (now === '') !== (mark === '')) { el.removeAttribute('cf-keep'); kept.delete(el); for (const f of el.querySelectorAll('[cf-flip],[cf-tone]')) { f.removeAttribute('cf-flip'); f.removeAttribute('cf-tone'); flipped.delete(f); } }
    }
    for (const el of flipped) {
      if (!el.isConnected) { flipped.delete(el); continue; }
      const c = parseColor(getComputedStyle(el).backgroundColor);
      const gone = !c || c.a < 0.9 || !hasKeptAncestor(el) || (el.hasAttribute('cf-tone') ? c.sat < 0.35 : c.l < 0.45);
      if (gone) { el.removeAttribute('cf-flip'); el.removeAttribute('cf-tone'); flipped.delete(el); }
    }
  }
  // An element with an inline background picture (thumbnails, banners) should show its true colours too.
  function considerBackdrop(el) {
    if (mode !== 'inv' || el.hasAttribute('cf-keep')) return;
    const st = el.getAttribute('style');
    if (!st || st.indexOf('url(') < 0 || st.indexOf('background') < 0) return;
    keep(el, 'pic');
  }
  function clearKeep() {
    for (const el of kept.keys()) el.removeAttribute('cf-keep');
    kept.clear();
    for (const el of flipped) { el.removeAttribute('cf-flip'); el.removeAttribute('cf-tone'); }
    flipped.clear();
    for (const el of document.querySelectorAll('[cf-keep],[cf-flip],[cf-tone]')) { el.removeAttribute('cf-keep'); el.removeAttribute('cf-flip'); el.removeAttribute('cf-tone'); }
    boxQueue.length = 0; boxAt = 0;
  }

  /* ------------------------------------------------------------------ the look: one generated sheet for the page and every open shadow root */

  let lookSheet = null;
  const shadowRoots = new Set();
  const seenRoots = new Set();   // every open shadow root met so far; survives teardown so hidden fields stay watched
  const MEDIA = 'img:not([src$=".svg" i]):not([src*=".svg?" i]):not([src^="data:image/svg" i]),video,canvas,iframe,embed,object';
  const FLIP = 'filter:invert(1) hue-rotate(180deg) !important';
  const LABEL_CSS = '[data-cf-label]{font-size:0 !important}[data-cf-label]::after{content:attr(data-cf-label);content:attr(data-cf-label) / "";font-size:14px}' +
    Array.from({ length: 25 }, (_, i) => '[data-cf-fs="' + (i + 8) + '"]::after{font-size:' + (i + 8) + 'px}').join('');
  // Inside shadow roots the rules of content.css do not reach, so the media rules are repeated here.
  const BRONZE = 'sepia(1) saturate(2.8) hue-rotate(-8deg) ';
  // Consent and cookie dialogs often live in frames; those are left flipped so they come out dark like the page.
  const CONSENT_FRAME = 'iframe:is([id^="sp_message" i],[src*="consent" i],[src*="privacy-mgmt" i],[src*="cookie" i],[title*="consent" i],[title*="cookie" i],[title*="privacy" i],[name*="consent" i])';
  const SHADOW_INV_CSS = ':is(' + MEDIA + ',[cf-keep]){' + FLIP + '}' +
    '[cf-keep="bl"][cf-keep][cf-keep][cf-keep]{filter:' + BRONZE + 'brightness(.72) invert(1) hue-rotate(180deg) !important}' +
    '[cf-keep="bd"][cf-keep][cf-keep][cf-keep]{filter:' + BRONZE + 'invert(1) hue-rotate(180deg) !important}' +
    CONSENT_FRAME + ':not([cf-keep] *){filter:none !important}' +
    '[cf-keep] [cf-tone="l"][cf-tone][cf-tone]{filter:' + BRONZE + 'brightness(.72) !important}' +
    '[cf-keep] [cf-tone="d"][cf-tone][cf-tone]{filter:' + BRONZE + '!important}' +
    '[cf-keep][cf-keep][cf-keep] :is(img,video,canvas,iframe,embed,object,[cf-keep]){filter:none !important}' +
    ':host-context([cf-keep]) :is(img,video,canvas,iframe,embed,object,[cf-keep]){filter:none !important}' +
    '[cf-keep][cf-keep][cf-keep] [cf-flip][cf-flip]{' + FLIP + '}' +
    '[cf-keep][cf-keep][cf-keep] [cf-flip][cf-flip] :is(' + MEDIA + '){' + FLIP + '}';
  // The palette, as it should look on screen.
  const INK = {
    link: [228, 184, 98], linkv: [178, 148, 108], linkh: [255, 224, 150], head: [242, 221, 174],
    selbg: [120, 22, 22], seltx: [250, 236, 206], gold: [205, 156, 62], golddim: [118, 90, 44], track: [22, 18, 15]
  };
  const SERIF = '"Palatino Linotype","Book Antiqua",Palatino,"Iowan Old Style",Georgia,serif';
  const NOT_BUTTON = ':not([role="button"]):not([role="tab"]):not([role="menuitem"]):not([role="option"]):not([class*="btn" i]):not([class*="button" i]):not([class*="chip" i]):not([class*="badge" i])';
  function lookCss() {
    const vars = (f) => Object.keys(INK).map((k) => '--cf-' + k + ':rgb(' + f(INK[k]).join(',') + ')').join(';');
    const lightInk = (f) => '--cf-link:rgb(' + f([255, 240, 208]).join(',') + ');--cf-linkv:rgb(' + f([236, 220, 190]).join(',') + ');--cf-linkh:rgb(' + f([255, 255, 255]).join(',') + ');--cf-head:rgb(' + f([255, 244, 216]).join(',') + ')';
    const darkInk = (f) => '--cf-link:rgb(' + f([34, 20, 8]).join(',') + ');--cf-linkv:rgb(' + f([58, 40, 22]).join(',') + ');--cf-linkh:rgb(' + f([0, 0, 0]).join(',') + ');--cf-head:rgb(' + f([28, 16, 6]).join(',') + ')';
    let css = 'html[cf-on]{' + vars(preRoot) + '}[cf-keep]{' + vars(preKept) + '}' +
      // on a strong colour, gold lettering would be hard to read: use cream or near-black to match the box's own text
      '[cf-keep$="l"],[cf-tone="l"]{' + lightInk(preKept) + '}[cf-keep$="d"],[cf-tone="d"]{' + darkInk(preKept) + '}' +
      '[cf-flip]{' + vars(preRoot) + '}';
    css += LABEL_CSS;
    if (level >= 2) {
      const link = 'a:any-link' + NOT_BUTTON;
      css += '::selection{background-color:var(--cf-selbg) !important;color:var(--cf-seltx) !important}' +
        'html[cf-on]{accent-color:var(--cf-gold);scrollbar-color:var(--cf-golddim) var(--cf-track)}' +
        link + '{color:var(--cf-link) !important;text-decoration-color:var(--cf-golddim)}' +
        link + ':visited{color:var(--cf-linkv) !important}' +
        link + ':hover{color:var(--cf-linkh) !important}' +
        ':is(h1,h2,h3){color:var(--cf-head) !important}' +
        link + ' :is(h1,h2,h3),:is(h1,h2,h3) ' + link + '{color:var(--cf-link) !important}' +
        link + ':hover :is(h1,h2,h3),:is(h1,h2,h3) ' + link + ':hover{color:var(--cf-linkh) !important}' +
        'hr{border-color:var(--cf-golddim) !important}' +
        // dark buttons that kept their own colours get a thin gold rim so they do not vanish into the page
        ':is(button,a,input,[role="button"])[cf-keep]{box-shadow:0 0 0 1px var(--cf-golddim) !important}';
      // headings and link titles inside a link keep the link's own ink on coloured boxes too

      if (settings.fonts !== false) {
        const body = level === 3 ? '"CF Fell","CF Garamond",' + SERIF : '"CF Garamond",' + SERIF;
        const cinzel = '"CF Cinzel","Cinzel","Trajan Pro",' + SERIF;
        const black = '"CF Pirata","Pirata One","UnifrakturCook","Old English Text MT","CF Cinzel",' + SERIF;
        const NOT_ICON = ':not([class*="icon" i]):not([class*="glyph" i]):not([class*="material" i]):not([class*="symbol" i]):not([class*="fa-" i]):not([class^="fa" i]):not([class*="mdi" i]):not([class*="ion-" i]):not([class*="emoji" i]):not([class*="mono" i]):not([class*="code" i]):not([class*="katex" i]):not([class*="math" i]):not([aria-hidden="true"])';
        css += ':is(body,p,li,dd,dt,blockquote,figcaption,td,th,label,yt-formatted-string){font-family:' + body + ' !important}' +
          ':is(span,div,a,strong,b,em,cite,small,button)' + NOT_ICON + '{font-family:' + body + ' !important}' +
          ':is(pre,code,kbd,samp,tt):not(#cf-x),:is(pre,code,kbd,samp,tt) :not(#cf-x),[class*="blob-code" i]:not(#cf-x),[class*="blob-code" i] :not(#cf-x),:is(.CodeMirror,.monaco-editor,.cm-editor,.ace_editor,.xterm) :not(#cf-x){font-family:ui-monospace,"Cascadia Mono",Consolas,"SF Mono",Menlo,monospace !important}' +
          ':is(h1,h2,h3){font-family:' + cinzel + ' !important;letter-spacing:.03em}' +
          // long titles that are links (search results, products, videos) read better in mixed case
          'a :is(h1,h2,h3),:is(h1,h2,h3) a{font-family:' + body + ' !important;letter-spacing:normal}' +
          (level === 3 ? 'h1{font-family:' + black + ' !important;letter-spacing:.02em}' : '') +
          ':is(h1,h2){text-shadow:0 0 18px color-mix(in srgb,var(--cf-gold) 35%,transparent)}';
        if (theme) css += THEME_CSS[theme.id] ? THEME_CSS[theme.id](body, cinzel, black) : '';
      }
    }
    return css;
  }
  // Site touches (kept small on purpose; site markup changes often).
  const THEME_CSS = {
    youtube: (b, c) => ':is(#video-title,h1.ytd-watch-metadata,.yt-lockup-metadata-view-model__title,.yt-core-attributed-string--white-space-pre-wrap){font-family:' + b + ' !important}',
    amazon: (b, c) => ':is(#productTitle,#title){font-family:' + c + ' !important;letter-spacing:.02em}',
    reddit: (b) => ':is([slot="title"],[id^="post-title"]){font-family:' + b + ' !important}',
    wikipedia: (b, c, k) => ':is(.mw-page-title-main,.vector-toc-title){font-family:' + c + ' !important;letter-spacing:.02em}' + (level === 3 ? '.mw-page-title-main{font-family:' + k + ' !important}' : '') +
      '.mw-parser-output{font-family:' + b + ' !important}'
  };
  function syncLookSheet() {
    try {
      if (!lookSheet) lookSheet = new CSSStyleSheet();
      lookSheet.replaceSync('@media screen{' + (mode === 'inv' && !fsSuspended ? SHADOW_INV_CSS : '') + lookCss() + '}');
    } catch (e) { lookSheet = null; }
  }
  function adoptDocSheet() {
    if (!lookSheet) return;
    try { if (!document.adoptedStyleSheets.includes(lookSheet)) document.adoptedStyleSheets = [...document.adoptedStyleSheets, lookSheet]; } catch (e) {}
  }
  function adoptShadow(sr) {
    if (shadowRoots.has(sr)) return;
    try {
      if (!lookSheet) syncLookSheet();
      if (!lookSheet) return;
      sr.adoptedStyleSheets = [...sr.adoptedStyleSheets, lookSheet];
      shadowRoots.add(sr);
      if (observer) observer.observe(sr, OBSERVE);   // later changes inside this root are watched like the page itself
    } catch (e) { /* some browsers refuse cross-world sheets; media in those roots stays flipped */ }
  }
  function dropShadowSheets() {
    for (const sr of shadowRoots) {
      try { sr.adoptedStyleSheets = sr.adoptedStyleSheets.filter((s) => s !== lookSheet); } catch (e) {}
    }
    shadowRoots.clear();
    try { if (lookSheet) document.adoptedStyleSheets = document.adoptedStyleSheets.filter((s) => s !== lookSheet); } catch (e) {}
  }

  /* ------------------------------------------------------------------ labels */

  const labels = CF.labelsFor(theme);
  const marked = new Set();
  const markedKey = new WeakMap();
  const refused = new WeakSet();
  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'OPTGROUP', 'DATALIST',
    'CODE', 'PRE', 'KBD', 'SAMP', 'svg', 'IFRAME', 'CANVAS', 'VIDEO', 'AUDIO', 'TEMPLATE', 'CF-VEIL', 'MATH', 'OUTPUT', 'METER', 'PROGRESS', 'TIME']);
  const CONTROL = 'button,a,[role="button"],[role="tab"],[role="menuitem"],[role="link"],summary,.a-button-inner,.btn,.button';
  // Places where text belongs to people, not to the site's interface.
  const USER_CONTENT = 'p,article,blockquote,h1,h2,h3,h4,h5,h6,li p,td p,figcaption,address,label,legend,fieldset,' +
    '[contenteditable],[role="article"],[role="textbox"],[role="listitem"],[role="row"],[role="gridcell"],[role="option"],[role="combobox"],' +
    '[itemprop="articleBody"],[itemprop="text"],[itemprop="reviewBody"],[itemprop="description"],[data-hook="review-body"],' +
    '[class*="comment" i],[id*="comment" i],[class*="review-text" i],[class*="post-body" i],[class*="post-content" i],' +
    '[class*="markdown" i],[class*="user-content" i],[class*="usertext" i],[class*="message-body" i],[class*="msg-body" i],' +
    '[slot="comment"],[slot="text-body"],.md,.a3s,.ii,#content-text,#description,ytd-text-inline-expander,ytd-comment-view-model,' +
    '.mw-parser-output,#mw-content-text,#bodyContent,#productDescription,#feature-bullets,#aplus';

  // closest() that also climbs out of shadow roots, so a comment component's inner links still count as user content.
  function closestDeep(el, sel) {
    for (let n = el; n; ) {
      const hit = n.closest(sel);
      if (hit) return hit;
      const r = n.getRootNode();
      n = r && r.host ? r.host : null;
    }
    return null;
  }
  const norm = (s) => s.replace(/\s+/g, ' ').trim().toLowerCase();

  function controlIsJustLabel(control, key) {
    const rest = norm(control.textContent).replace(key, '');
    return rest.length <= 8 && !/[^\d\s.,+()\[\]·•|:\-–]/.test(rest);
  }
  function considerText(t) {
    const v = t.nodeValue;
    if (!v || v.length < 2 || v.length > 48) return;
    const key = norm(v);
    const label = labels.get(key);
    if (!label) return;
    const el = t.parentElement;
    if (!el || marked.has(el) || refused.has(el)) return;
    if (SKIP.has(el.nodeName) || el.isContentEditable) return;
    if (el.childElementCount !== 0 || norm(el.textContent) !== key) return;
    const control = el.closest(CONTROL);
    if (!control) return;
    // The control may hold a count or an icon next to the label ("3 Cart"), but no other words.
    if (!controlIsJustLabel(control, key)) return;
    if (control.isContentEditable || closestDeep(control, 'form[action*="login" i],form[action*="sign" i]')) return;
    if (closestDeep(el, USER_CONTENT)) return;
    pendingMarks.push([el, key, label]);
    if (!markFrame) markFrame = requestAnimationFrame(flushMarks);
  }

  const pendingMarks = [];
  let markFrame = 0;
  function flushMarks() {
    markFrame = 0;
    if (!active || !settings.labels) { pendingMarks.length = 0; return; }
    const batch = pendingMarks.splice(0, 120);            // keep each frame's work small
    if (pendingMarks.length) markFrame = requestAnimationFrame(flushMarks);
    const ready = [];
    // read phase
    for (const [el, key, label] of batch) {
      if (!el.isConnected || marked.has(el) || norm(el.textContent) !== key) continue;
      const cs = getComputedStyle(el);
      const fs = Math.round(parseFloat(cs.fontSize));
      if (!(fs >= 8 && fs <= 32)) continue;
      const none = (c) => !c || c === 'none' || c === 'normal';
      if (!none(getComputedStyle(el, '::after').content) || !none(getComputedStyle(el, '::before').content)) continue;
      // Measure a box that has a real height: an inline element has none of its own, so walk up to the first non-inline ancestor.
      let box = el;
      for (let i = 0; i < 6 && box.parentElement && getComputedStyle(box).display === 'inline'; i++) box = box.parentElement;
      ready.push([el, key, label, fs, box.getBoundingClientRect().height, box]);
    }
    // write phase
    for (const [el, key, label, fs] of ready) {
      el.setAttribute('data-cf-label', label);
      el.setAttribute('data-cf-fs', String(fs));
      marked.add(el); markedKey.set(el, key);
    }
    // verify phase: if hiding the original collapsed the control, put it back for good
    for (const [el, , , , h0, box] of ready) {
      const h1 = box.getBoundingClientRect().height;
      if (h0 > 0 && h1 < h0 * 0.7) { unmark(el); refused.add(el); }
    }
  }

  function unmark(el) {
    el.removeAttribute('data-cf-label');
    el.removeAttribute('data-cf-fs');
    marked.delete(el);
  }
  // A site may clone a relabelled element or re-insert its HTML. The copy carries our attribute but is not
  // tracked, so its painted label could go stale. Remove it at once; a normal scan re-adds it if still right.
  function stripForeign(n) {
    if (n.hasAttribute('data-cf-label') && !marked.has(n)) { n.removeAttribute('data-cf-label'); n.removeAttribute('data-cf-fs'); }
    if (n.hasAttribute('cf-keep') && !kept.has(n)) n.removeAttribute('cf-keep');
    if ((n.hasAttribute('cf-flip') || n.hasAttribute('cf-tone')) && !flipped.has(n)) { n.removeAttribute('cf-flip'); n.removeAttribute('cf-tone'); }
    if (!n.firstElementChild) return;
    for (const el of n.querySelectorAll('[data-cf-label]')) if (!marked.has(el)) { el.removeAttribute('data-cf-label'); el.removeAttribute('data-cf-fs'); }
    for (const el of n.querySelectorAll('[cf-keep]')) if (!kept.has(el)) el.removeAttribute('cf-keep');
    for (const el of n.querySelectorAll('[cf-flip],[cf-tone]')) if (!flipped.has(el)) { el.removeAttribute('cf-flip'); el.removeAttribute('cf-tone'); }
  }
  function clearLabels() {
    for (const el of marked) { el.removeAttribute('data-cf-label'); el.removeAttribute('data-cf-fs'); }
    marked.clear();
    pendingMarks.length = 0;
    // also anything left behind by an earlier copy of this script
    for (const el of document.querySelectorAll('[data-cf-label]')) { el.removeAttribute('data-cf-label'); el.removeAttribute('data-cf-fs'); }
  }
  // The real text under a painted label changed (say "Subscribe" became "Subscribed"): drop or update at once.
  function revalidate(el) {
    if (!marked.has(el)) return;
    const key = markedKey.get(el);
    if (el.isConnected && el.childElementCount === 0 && norm(el.textContent) === key) {
      const control = el.closest(CONTROL);
      if (control && controlIsJustLabel(control, key)) return;   // still the whole label of its control
    }
    unmark(el);
    if (el.isConnected && active && settings.labels) for (const c of el.childNodes) if (c.nodeType === 3) considerText(c);
  }

  /* ---- scanning, in idle slices ---- */
  const queue = [];
  let walker = null;
  let scanScheduled = false;
  let fullScanWanted = false;
  let fullScanTimer = 0;

  function scheduleFullScan() {
    if (fullScanTimer) return;
    fullScanTimer = setTimeout(() => { fullScanTimer = 0; fullScanWanted = true; queue.length = 0; walker = null; pump(); }, 300);
  }
  function enqueue(node) {
    if (queue.length > 1500) { scheduleFullScan(); return; }
    queue.push(node);
    pump();
  }
  function pump() {
    if (scanScheduled) return;
    scanScheduled = true;
    idle(scanSlice);
  }
  function makeWalker(rootNode) {
    return document.createTreeWalker(rootNode, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, {
      acceptNode(n) {
        if (n.nodeType === 1) return SKIP.has(n.nodeName) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });
  }
  function visit(n) {
    if (n.nodeType === 3) { if (settings.labels) considerText(n); return; }
    if (mode === 'inv') { if (n.hasAttribute('style')) considerBackdrop(n); if (boxWorthy(n)) queueBox(n); }
    const sr = n.shadowRoot;
    if (sr && !shadowRoots.has(sr)) {
      // A password or card field hidden inside a component's shadow DOM protects the page too.
      seenRoots.add(sr);
      if (!stickyReason && domSensitive(sr)) { tripSensitive('protected:password-or-card-field'); return; }
      adoptShadow(sr); queue.push(sr);
    }
  }
  function scanSlice(deadline) {
    scanScheduled = false;
    if (!active) { queue.length = 0; walker = null; return; }
    const t0 = performance.now();
    const budget = () => (deadline.timeRemaining ? deadline.timeRemaining() > 1 : true) && performance.now() - t0 < 12;
    let steps = 0;
    for (;;) {
      if (!walker) {
        let next = null;
        if (fullScanWanted) { fullScanWanted = false; next = document.body; }
        else next = queue.shift();
        if (!next) return;
        if (next.nodeType === 1 && (!next.isConnected || SKIP.has(next.nodeName))) continue;
        if (next.nodeType === 1) visit(next);
        walker = makeWalker(next);
      }
      let n;
      while (walker && (n = walker.nextNode())) {
        visit(n);
        if (!active) { queue.length = 0; walker = null; return; }   // the visit found a protected field and stood down
        if ((++steps & 63) === 0 && !budget()) { pump(); return; }
      }
      walker = null;
      if (!budget()) { if (queue.length || fullScanWanted) pump(); return; }
    }
  }

  /* ------------------------------------------------------------------ watching the page */

  let observer = null;
  const OBSERVE = { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['type', 'autocomplete'] };
  // Last line of defence: the moment focus lands in a password or card field anywhere, including inside
  // open shadow DOM that the scans have not reached yet, stand down before a single key is typed.
  window.addEventListener('focusin', (e) => {
    if (dead || stickyReason || !settings.enabled) return;
    const t = e.composedPath ? e.composedPath()[0] : e.target;
    if (t && t.nodeType === 1 && t.nodeName === 'INPUT' && t.matches(CF.sensitive.DOM_SELECTOR)) tripSensitive('protected:password-or-card-field');
  }, { capture: true, passive: true });
  function watch(on) {
    if (on && !observer && html) {
      observer = new MutationObserver(onMutations);
      observer.observe(html, OBSERVE);
      for (const sr of shadowRoots) observer.observe(sr, OBSERVE);
    } else if (!on && observer) {
      observer.disconnect(); observer = null;
    }
  }
  function onMutations(records) {
    for (const m of records) {
      if (m.type === 'characterData') {
        const p = m.target.parentElement;
        if (p && marked.has(p)) revalidate(p);
        else if (active && settings.labels && p) considerText(m.target);
        continue;
      }
      if (m.type === 'attributes') {
        if (!stickyReason && m.target.nodeName === 'INPUT' && domSensitive(m.target)) return tripSensitive('protected:password-or-card-field');
        continue;
      }
      if (marked.has(m.target)) revalidate(m.target);
      for (const n of m.addedNodes) {
        if (n.nodeType === 1) {
          if (n.nodeName === 'CF-VEIL') continue;
          if (!stickyReason && domSensitive(n)) return tripSensitive('protected:password-or-card-field');
          stripForeign(n);
          if (active) enqueue(n);
        } else if (n.nodeType === 3 && active && settings.labels) {
          considerText(n);
        }
      }
    }
  }

  // Slow safety sweep: address changes in single-page apps, labels that drifted, theme flips, Gmail's unread count.
  let ticker = 0, tick = 0, modeDoubt = 0;
  function startTicker() { if (!ticker) ticker = setInterval(onTick, 1500); }
  function stopTicker() { clearInterval(ticker); ticker = 0; }
  function onTick() {
    if (dead) return stopTicker();
    if (!api.runtime || !api.runtime.id) { dead = true; teardown(); return stopTicker(); }
    if (document.hidden || !settings.enabled) return;
    tick++;
    if (location.href !== lastHref) return onUrlChange();
    // A sign-in box can be revealed without any node being added, and can go away again.
    if (!stickyReason) {
      if (active && sensitiveNow()) return tripSensitive('protected:password-or-card-field');
    } else if (!sensitiveNow()) {
      if (++clearTicks >= 2) { clearTicks = 0; stickyReason = null; evaluate(); if (active) { scheduleKeep(); scheduleFullScan(); } }
    } else clearTicks = 0;
    for (const el of marked) {
      if (!el.isConnected) { marked.delete(el); continue; }
      revalidate(el);
    }
    if (!active) return;
    if (tick % 2 === 0) {
      const d = detectMode();
      // a change of mind needs two looks in a row, so a passing overlay cannot flip the whole page
      if (d.mode !== mode) { if (++modeDoubt >= 2) { modeDoubt = 0; apply(); } } else modeDoubt = 0;
      if (!html.hasAttribute('cf-on') || (!fsSuspended && !html.hasAttribute('cf-mode'))) apply();
    }
    for (const el of document.querySelectorAll('[data-cf-label]')) if (!marked.has(el)) stripForeign(el);
    adoptDocSheet();
    if (mode === 'inv' && tick % 2 === 1) revalidateKeep();
    if (mode === 'inv' && tick % 4 === 2) rescanBoxes();
    if (veil && !veil.host.isConnected) { ensureVeil(); paintVeil(); }   // a page re-render threw the overlay away
    if (theme && theme.id === 'gmail') watchUnread();
    if (tick % 30 === 0) rollEvent();
  }
  function onUrlChange() {
    lastHref = location.href;
    evaluate();
    if (active) { scheduleKeep(); scheduleFullScan(); }
  }

  /* ------------------------------------------------------------------ the veil (overlay) */

  let veil = null;
  const GRAIN = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='180' height='180'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 .5 0 0 0 0 .5 0 0 0 0 .5 0 0 0 1.4 -.45'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")";
  const MOTTLE = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='600' height='600'%3E%3Cfilter id='m'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.006' numOctaves='3' seed='7' stitchTiles='stitch'/%3E%3CfeColorMatrix values='0 0 0 0 .5 0 0 0 0 .5 0 0 0 0 .5 0 0 0 1.6 -.6'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23m)'/%3E%3C/svg%3E\")";
  const VEIL_CSS = `
    :host{all:initial;position:fixed;inset:0;display:block;pointer-events:none;z-index:2147483647;contain:strict;overflow:hidden}
    @media print{:host{display:none !important}}
    .l{position:absolute;inset:0}
    .grain{background-image:${GRAIN};background-size:180px 180px;opacity:var(--grain)}
    .vig{background:radial-gradient(ellipse 78% 82% at 50% 48%,transparent 62%,var(--vig) 128%)}
    .glow{opacity:var(--glowo);background:
      radial-gradient(circle at 0% 100%,var(--glow) 0,transparent 30%),
      radial-gradient(circle at 100% 100%,var(--glow) 0,transparent 30%);
      animation:flick 6.5s infinite ease-in-out;will-change:opacity}
    @keyframes flick{0%,100%{opacity:var(--glowo)}18%{opacity:calc(var(--glowo)*.82)}23%{opacity:calc(var(--glowo)*1.04)}47%{opacity:calc(var(--glowo)*.9)}52%{opacity:calc(var(--glowo)*.74)}58%{opacity:calc(var(--glowo)*.98)}81%{opacity:calc(var(--glowo)*.86)}}
    .frame{display:none}
    :host([frame]) .frame{display:block}
    .frame b{position:absolute;display:block;background:var(--line)}
    .frame b.t{left:46px;right:46px;top:4px;height:1px}.frame b.b{left:46px;right:46px;bottom:4px;height:1px}
    .frame b.lf{top:46px;bottom:46px;left:4px;width:1px}.frame b.r{top:46px;bottom:46px;right:4px;width:1px}
    .frame svg{position:absolute;width:46px;height:46px;top:1px;left:1px;overflow:visible;opacity:.8}
    .frame svg.tr{left:auto;right:1px;transform:scaleX(-1)}
    .frame svg.bl{top:auto;bottom:1px;transform:scaleY(-1)}
    .frame svg.br{top:auto;left:auto;right:1px;bottom:1px;transform:scale(-1,-1)}
    .fog{display:none;overflow:hidden}
    :host([fog]) .fog{display:block}
    .fog i{position:absolute;left:0;bottom:-10%;width:200%;height:70%;will-change:transform;
      background:radial-gradient(ellipse 22% 38% at 12% 70%,var(--fogc) 0,transparent 100%),radial-gradient(ellipse 26% 44% at 38% 80%,var(--fogc) 0,transparent 100%),
      radial-gradient(ellipse 22% 38% at 62% 70%,var(--fogc) 0,transparent 100%),radial-gradient(ellipse 26% 44% at 88% 80%,var(--fogc) 0,transparent 100%);
      animation:drift 70s linear infinite}
    .fog i+i{bottom:auto;top:-18%;height:55%;opacity:.55;animation-duration:110s;animation-direction:reverse}
    @keyframes drift{from{transform:translateX(0)}to{transform:translateX(-50%)}}
    .ember{position:absolute;bottom:-8px;width:3px;height:3px;border-radius:50%;background:var(--ember);box-shadow:0 0 6px 1px var(--ember);opacity:0;will-change:transform,opacity;animation:ember linear infinite}
    @keyframes ember{0%{transform:translate(0,0);opacity:0}8%{opacity:.9}60%{opacity:.55}100%{transform:translate(var(--dx),-46vh);opacity:0}}
    .dark{background:var(--vig);opacity:0}
    .dark.out{animation:out 4.6s ease-in-out}
    .glow.out{animation:gout 4.6s linear}
    @keyframes out{0%{opacity:0}12%{opacity:.25}16%{opacity:.08}24%{opacity:.62}78%{opacity:.62}100%{opacity:0}}
    @keyframes gout{0%{opacity:var(--glowo)}8%{opacity:.1}12%{opacity:var(--glowo)}18%{opacity:0}80%{opacity:0}86%{opacity:calc(var(--glowo)*.5)}100%{opacity:var(--glowo)}}
    .un{filter:var(--un)}
    .sprite{position:absolute;will-change:transform,opacity}
    .spider svg,.crawl svg,.raven svg{filter:drop-shadow(0 0 1.5px rgba(255,220,170,.95)) drop-shadow(0 0 7px rgba(255,170,80,.55))}
    .spider{top:0;animation:spider 9s ease-in-out forwards}
    .spider .thread{position:absolute;left:50%;bottom:100%;width:1px;height:100vh;background:rgba(220,220,220,.55)}
    @keyframes spider{0%{transform:translateY(-80px)}35%{transform:translateY(34vh)}45%{transform:translateY(31vh)}58%{transform:translateY(36vh)}100%{transform:translateY(-90px)}}
    .crawl{bottom:6px;left:0;animation:crawl 11s linear forwards}
    @keyframes crawl{0%{transform:translateX(-60px) rotate(90deg)}100%{transform:translateX(calc(100vw + 60px)) rotate(90deg)}}
    .ghost{left:0;animation:ghost 10s ease-in-out forwards;opacity:0}
    @keyframes ghost{0%{transform:translate(-120px,0);opacity:0}15%{opacity:.55}30%{transform:translate(28vw,-26px)}50%{transform:translate(50vw,14px);opacity:.5}70%{transform:translate(72vw,-20px)}88%{opacity:.4}100%{transform:translate(calc(100vw + 120px),6px);opacity:0}}
    .raven{left:0;top:9vh;animation:raven 6.5s linear forwards}
    .raven .wing{transform-origin:50% 60%;animation:flap .42s ease-in-out infinite alternate}
    @keyframes raven{0%{transform:translate(-140px,6vh)}45%{transform:translate(46vw,-2vh)}55%{transform:translate(54vw,1vh)}100%{transform:translate(calc(100vw + 140px),-7vh)}}
    @keyframes flap{from{transform:scaleY(1)}to{transform:scaleY(-.55)}}
    .toasts{position:absolute;left:0;right:0;bottom:26px;display:flex;flex-direction:column;align-items:center;gap:8px}
    .toast{font:600 15px/1.35 "CF Cinzel","Palatino Linotype","Book Antiqua",Georgia,serif;letter-spacing:.05em;color:#f0dcae;
      background:linear-gradient(#1d1611,#120d0a);border:1px solid #8a6a2f;border-radius:2px;padding:10px 22px;max-width:min(80vw,480px);text-align:center;
      box-shadow:0 0 0 3px #0b0806,0 0 0 4px #5a4420,0 8px 26px rgba(0,0,0,.7);animation:toast 5.2s ease forwards}
    .card{position:absolute;left:50%;top:13vh;transform:translateX(-50%);text-align:center;white-space:nowrap;padding:16px 44px 18px;
      font:700 26px/1.2 "CF Cinzel","Palatino Linotype","Book Antiqua",Georgia,serif;letter-spacing:.09em;color:#f3deaa;text-shadow:0 0 22px rgba(240,180,80,.55),0 2px 3px #000;
      background:radial-gradient(ellipse at 50% 50%,rgba(10,7,5,.92) 0,rgba(10,7,5,.78) 55%,transparent 100%);animation:card 4.2s ease forwards}
    .card small{display:block;font:italic 400 15px/1.3 "CF Garamond","Palatino Linotype",Georgia,serif;letter-spacing:.04em;color:#c9a866;margin-bottom:6px;text-shadow:0 1px 2px #000}
    .card::after{content:"";display:block;height:1px;margin:10px auto 0;width:70%;background:linear-gradient(90deg,transparent,#c9973a,transparent)}
    @keyframes card{0%{opacity:0;letter-spacing:.2em}14%{opacity:1;letter-spacing:.09em}80%{opacity:1}100%{opacity:0}}
    @keyframes toast{0%{opacity:0;transform:translateY(14px)}8%{opacity:1;transform:none}86%{opacity:1}100%{opacity:0;transform:translateY(-6px)}}
    @media (prefers-reduced-motion:reduce){.glow,.fog i{animation:none}.ember{display:none}.card{animation-name:toast}}
  `;

  // One corner flourish; the other three are mirrored copies.
  const CORNER = [
    ['M11 22V64', '1.2', '.8'], ['M22 11H64', '1.2', '.8'],
    ['M11 30c10 0 19-9 19-19', '1.1', '.75'], ['M11 44c18 0 33-15 33-33', '.9', '.5'],
    ['M19 19c6 2 10 6 12 12M19 19c2 6 6 10 12 12', '1', '.7'],
    ['M11 64c0 4 3 6 6 5M64 11c4 0 6 3 5 6', '1.1', '.8']
  ];
  function ensureVeil() {
    if (veil && veil.host.isConnected) return;
    if (veil) { veil.host.remove(); veil.tint.remove(); veil.scene.remove(); veil = null; }
    const hostEl = document.createElement('cf-veil');
    hostEl.setAttribute('aria-hidden', 'true');
    const sr = hostEl.attachShadow({ mode: 'closed' });
    const st = document.createElement('style');
    st.textContent = VEIL_CSS;
    sr.appendChild(st);
    const mk = (cls, parent) => { const d = document.createElement('div'); d.className = cls; (parent || sr).appendChild(d); return d; };
    mk('l grain'); mk('l vig');
    const glow = mk('l glow');
    // Corner flourishes and a hairline border, drawn node by node.
    const frame = mk('l frame un');
    for (const c of ['t', 'b', 'lf', 'r']) { const b = document.createElement('b'); b.className = c; frame.appendChild(b); }
    for (const c of ['tl', 'tr', 'bl', 'br']) {
      const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      svg.setAttribute('viewBox', '0 0 76 76'); svg.setAttribute('class', c);
      for (const [d, w, o] of CORNER) {
        const pth = document.createElementNS('http://www.w3.org/2000/svg', 'path');
        pth.setAttribute('d', d); pth.setAttribute('fill', 'none'); pth.setAttribute('stroke', '#c9973a');
        pth.setAttribute('stroke-width', w); pth.setAttribute('stroke-linecap', 'round'); pth.setAttribute('opacity', o);
        svg.appendChild(pth);
      }
      const dot = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      dot.setAttribute('d', 'M11 5l6 6-6 6-6-6z'); dot.setAttribute('fill', '#c9973a'); dot.setAttribute('opacity', '.9');
      svg.appendChild(dot);
      frame.appendChild(svg);
    }
    const embers = mk('l embers un');
    for (let i = 0; i < 9; i++) {
      const e = document.createElement('i'); e.className = 'ember';
      const side = i % 2 ? 100 - (2 + Math.random() * 16) : 2 + Math.random() * 16;
      e.style.cssText = 'left:' + side.toFixed(1) + 'vw;--dx:' + Math.round((Math.random() - 0.5) * 90) + 'px;animation-duration:' + (7 + Math.random() * 9).toFixed(1) + 's;animation-delay:-' + (Math.random() * 14).toFixed(1) + 's';
      embers.appendChild(e);
    }
    const fog = mk('l fog'); fog.appendChild(document.createElement('i')); fog.appendChild(document.createElement('i'));
    const dark = mk('l dark');
    const stage = mk('l stage');
    const toasts = mk('toasts');
    // The parchment cast has to blend with the page itself, so it is its own top-level element.
    const tintEl = document.createElement('cf-veil');
    tintEl.setAttribute('aria-hidden', 'true');
    const tst = document.createElement('style');
    tst.textContent = ':host{all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483646;display:none;background-color:var(--c);mix-blend-mode:var(--b)}:host([on]){display:block}@media print{:host{display:none !important}}';
    tintEl.attachShadow({ mode: 'closed' }).appendChild(tst);
    // The scene: a painting behind the page. It is blended so that it only shows where the page is dark,
    // which leaves text, pictures and bright boxes as they are.
    const sceneEl = document.createElement('cf-veil');
    sceneEl.setAttribute('aria-hidden', 'true');
    const sst = document.createElement('style');
    let sceneUrl = '';
    try { sceneUrl = api.runtime.getURL('scene/castle.jpg'); } catch (e) {}
    sst.textContent = ':host{all:initial;position:fixed;inset:0;pointer-events:none;z-index:2147483645;display:none;contain:strict;' +
      'background:#000 url("' + sceneUrl + '") center bottom/cover no-repeat;mix-blend-mode:lighten;opacity:var(--o,.8)}' +
      ':host([on]){display:block}:host([inv]){filter:invert(1) hue-rotate(180deg);mix-blend-mode:darken}@media print{:host{display:none !important}}';
    sceneEl.attachShadow({ mode: 'closed' }).appendChild(sst);
    veil = { host: hostEl, tint: tintEl, scene: sceneEl, sr, glow, dark, stage, toasts, embers };
    html.appendChild(sceneEl);
    html.appendChild(tintEl);
    html.appendChild(hostEl);
  }

  function paintVeil() {
    if (!veil) return;
    const k = Math.max(0, Math.min(1, settings.intensity / 100));
    const g = theme ? theme.glow : [255, 170, 80];
    const tint = theme ? theme.tint : [244, 232, 206];
    const s = veil.host.style;
    s.setProperty('--vig', paint([3, 2, 1], (0.3 + 0.4 * k).toFixed(3)));
    s.setProperty('--grain', level === 1 ? '0' : (0.03 + 0.05 * k).toFixed(3));
    s.setProperty('--glow', paint(g, (0.05 + 0.1 * k).toFixed(3)));
    s.setProperty('--glowo', level === 1 ? '0.45' : '1');
    s.setProperty('--fogc', paint([196, 206, 214], (0.1 + 0.12 * k).toFixed(3)));
    s.setProperty('--line', 'rgba(201,151,58,' + (0.18 + 0.3 * k).toFixed(2) + ')');
    s.setProperty('--ember', 'rgba(' + g[0] + ',' + g[1] + ',' + g[2] + ',.9)');
    if (level >= 2) veil.host.setAttribute('frame', ''); else veil.host.removeAttribute('frame');
    veil.embers.style.display = settings.fog && level >= 2 ? '' : 'none';
    // Full curse only: a parchment cast over everything. On a flipped page "multiply after the flip" is "screen before it".
    const ts = veil.tint.style;
    // Only used when the person turned darkening off: the warm grade already covers every other case.
    if (level === 3 && mode === 'dark' && !graded) veil.tint.setAttribute('on', ''); else veil.tint.removeAttribute('on');
    ts.setProperty('--c', mode === 'inv' ? rgba(invertMap(F_FLIP)(tint), 1) : rgba(tint, 1));
    ts.setProperty('--b', mode === 'inv' ? 'screen' : 'multiply');
    s.setProperty('--un', mode === 'inv' ? 'invert(1) hue-rotate(180deg)' : 'none');
    if (settings.fog) veil.host.setAttribute('fog', ''); else veil.host.removeAttribute('fog');
    const sc = veil.scene;
    if (settings.scene !== false && !fsSuspended && (mode === 'inv' || graded)) sc.setAttribute('on', ''); else sc.removeAttribute('on');
    if (mode === 'inv') sc.setAttribute('inv', ''); else sc.removeAttribute('inv');
    sc.style.setProperty('--o', (0.55 + 0.4 * k).toFixed(2));
  }

  function card(small, big) {
    if (!veil) return;
    const c = document.createElement('div');
    c.className = 'card un';
    const s1 = document.createElement('small'); s1.textContent = small;
    c.appendChild(s1); c.appendChild(document.createTextNode(big));
    veil.stage.appendChild(c);
    setTimeout(() => c.remove(), 4300);
  }
  function toast(text) {
    if (!veil) return;
    const t = document.createElement('div');
    t.className = 'toast un';
    t.textContent = text;
    veil.toasts.appendChild(t);
    setTimeout(() => t.remove(), 5400);
  }

  /* ------------------------------------------------------------------ cursed events */

  // Sprites are built node by node (no HTML strings), so pages that enforce Trusted Types cannot block them.
  const NS = 'http://www.w3.org/2000/svg';
  const SPRITES = {
    spider: [60, 60, 46, 46, [
      ['path', { d: 'M24 30 10 20 4 26M24 33 8 32 2 40M25 37 12 44 8 54M28 39 20 50 20 58M36 30 50 20 56 26M36 33 52 32 58 40M35 37 48 44 52 54M32 39 40 50 40 58', stroke: '#15110f', 'stroke-width': '2.4', fill: 'none', 'stroke-linecap': 'round' }],
      ['ellipse', { cx: '30', cy: '36', rx: '9', ry: '11', fill: '#1c1613' }],
      ['circle', { cx: '30', cy: '24', r: '6', fill: '#1c1613' }],
      ['circle', { cx: '27.6', cy: '22.5', r: '1.3', fill: '#d33' }],
      ['circle', { cx: '32.4', cy: '22.5', r: '1.3', fill: '#d33' }],
      ['path', { d: 'M30 31v10M26 36h8', stroke: '#5a1d1d', 'stroke-width': '1.6' }]]],
    ghost: [64, 84, 96, 126, [
      ['path', { d: 'M32 4C16 4 7 17 7 33v45l8.5-8 8.2 8 8.3-8 8.3 8 8.2-8 8.500 8V33C57 17 48 4 32 4z', fill: '#e6eef6' }],
      ['circle', { cx: '23.5', cy: '31', r: '4.6', fill: '#18202a' }],
      ['circle', { cx: '40.5', cy: '31', r: '4.6', fill: '#18202a' }],
      ['ellipse', { cx: '32', cy: '46', rx: '4.2', ry: '6.5', fill: '#18202a' }]]],
    raven: [120, 70, 120, 70, [
      ['path', { d: 'M26 40c10-10 34-12 50-6l16-6 14 2-12 6c2 6-4 12-16 14-18 3-40 0-52-10z', fill: '#0d0c10' }],
      ['path', { d: 'M106 30l12 3-12 3z', fill: '#2a2620' }],
      ['path', { d: 'M26 40 4 50l20-2-12 12 20-12z', fill: '#0d0c10' }],
      ['path', { class: 'wing', d: 'M50 34C44 14 56 2 78 0c-6 8-2 14 4 22-8 0-20 4-32 12z', fill: '#0d0c10' }],
      ['circle', { cx: '98', cy: '31', r: '1.6', fill: '#c9c2b0' }],
      ['path', { d: 'M58 50l-4 12 8 2 6-12z', fill: '#e3d3a4', stroke: '#6b4f2a', 'stroke-width': '1' }]]]
  };
  function buildSprite(kind) {
    const [vw, vh, w, h, parts] = SPRITES[kind];
    const svg = document.createElementNS(NS, 'svg');
    svg.setAttribute('viewBox', '0 0 ' + vw + ' ' + vh);
    svg.setAttribute('width', w); svg.setAttribute('height', h);
    for (const [tag, attrs] of parts) {
      const el = document.createElementNS(NS, tag);
      for (const k in attrs) el.setAttribute(k, attrs[k]);
      svg.appendChild(el);
    }
    return svg;
  }
  let eventBusy = false;

  function sprite(kind, cls, css) {
    const d = document.createElement('div');
    d.className = 'sprite un ' + cls;
    d.appendChild(buildSprite(kind));
    if (css) d.style.cssText = css;
    veil.stage.appendChild(d);
    return d;
  }

  function runEvent(kind, extra) {
    if (!active || !veil || eventBusy || document.hidden) return false;
    if (reduceMotion.matches) { if (kind === 'raven') toast(extra || 'A raven circles overhead'); return false; }
    const kinds = ['spider', 'ghost', 'candle', 'crawl'];
    if (kind === 'random') kind = kinds[Math.floor(Math.random() * kinds.length)];
    eventBusy = true;
    let ms = 6000;
    if (kind === 'spider') {
      const d = sprite('spider', 'spider', 'left:' + Math.round(8 + Math.random() * 80) + 'vw');
      const th = document.createElement('div'); th.className = 'thread'; d.appendChild(th);
      ms = 9200; setTimeout(() => d.remove(), ms);
    } else if (kind === 'crawl') {
      const d = sprite('spider', 'crawl'); ms = 11200; setTimeout(() => d.remove(), ms); kind = 'spider';
    } else if (kind === 'ghost') {
      const d = sprite('ghost', 'ghost', 'top:' + Math.round(12 + Math.random() * 50) + 'vh');
      ms = 10200; setTimeout(() => d.remove(), ms);
    } else if (kind === 'candle') {
      veil.dark.classList.add('out'); veil.glow.classList.add('out');
      toast('A candle gutters out…');
      ms = 4800; setTimeout(() => { if (veil) { veil.dark.classList.remove('out'); veil.glow.classList.remove('out'); } }, ms);
    } else if (kind === 'raven') {
      const d = sprite('raven', 'raven'); ms = 6700; setTimeout(() => d.remove(), ms);
      setTimeout(() => toast(extra || 'A raven circles overhead'), 2600);
    } else { eventBusy = false; return false; }
    setTimeout(() => { eventBusy = false; }, ms + 400);
    bumpJournal((j) => { j.events[kind] = (j.events[kind] || 0) + 1; });
    return true;
  }

  // Called every 45 seconds of visible time. Rare by design: about one event per half hour at
  // the subtle end and one per seven or eight minutes at full curse.
  function rollEvent() {
    if (!settings.events || !active) return;
    const k = settings.intensity / 100;
    if (Math.random() < 0.02 + 0.08 * k) runEvent('random');
  }

  let unread = null;
  function watchUnread() {
    const m = /\((\d[\d,.]*)\)/.exec(document.title);   // read only; the title is never changed
    const n = m ? parseInt(m[1].replace(/[,.]/g, ''), 10) : 0;
    if (unread != null && n > unread && settings.events) {
      const d = n - unread;
      runEvent('raven', d === 1 ? 'A raven arrives bearing a new missive' : 'Ravens arrive bearing ' + d + ' new missives');
    }
    unread = n;
  }

  /* ------------------------------------------------------------------ ambient sound */

  let audio = null;
  function syncSound() {
    const want = active && settings.sound && !document.hidden;
    if (!want) { stopSound(); return; }
    if (audio && audio.kind === settings.soundKind) {
      audio.master.gain.setTargetAtTime(volumeGain(), audio.ctx.currentTime, 0.2);
      if (audio.ctx.state === 'suspended') audio.ctx.resume().catch(() => {});
      return;
    }
    stopSound();
    startSound();
  }
  const volumeGain = () => { const v = Math.max(0, Math.min(100, Number(settings.volume))); return (isNaN(v) ? 35 : v) / 100 * 1.2; };
  function startSound() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    let ctx;
    try { ctx = new AC(); } catch (e) { return; }
    const kind = settings.soundKind;
    const master = ctx.createGain(); master.gain.value = 0; master.connect(ctx.destination);
    master.gain.linearRampToValueAtTime(volumeGain(), ctx.currentTime + 3);
    const len = ctx.sampleRate * 3;
    const buf = ctx.createBuffer(1, len, ctx.sampleRate);
    const data = buf.getChannelData(0);
    let last = 0;
    for (let i = 0; i < len; i++) { const w = Math.random() * 2 - 1; last = (last + 0.02 * w) / 1.02; data[i] = last * 3.5; } // brown noise
    const noise = () => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; s.start(); return s; };
    const timers = [];
    if (kind !== 'wind') {
      const lp = ctx.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = 420;
      const g = ctx.createGain(); g.gain.value = 0.55;
      noise().connect(lp).connect(g).connect(master);
      const crackle = () => {
        if (!audio || audio.ctx !== ctx) return;
        if (ctx.state === 'running') {
          const n = 1 + Math.floor(Math.random() * 3);
          for (let i = 0; i < n; i++) {
            const t = ctx.currentTime + Math.random() * 0.25;
            const src = ctx.createBufferSource(); src.buffer = buf; src.playbackRate.value = 6 + Math.random() * 10;
            const hp = ctx.createBiquadFilter(); hp.type = 'highpass'; hp.frequency.value = 1400 + Math.random() * 2500;
            const eg = ctx.createGain(); const peak = 0.25 + Math.random() * 0.7;
            eg.gain.setValueAtTime(0, t); eg.gain.linearRampToValueAtTime(peak, t + 0.002);
            eg.gain.exponentialRampToValueAtTime(0.001, t + 0.02 + Math.random() * 0.05);
            src.connect(hp).connect(eg).connect(master);
            src.start(t, Math.random() * 2); src.stop(t + 0.1);
          }
        }
        timers[0] = setTimeout(crackle, 90 + Math.random() * 650);
      };
      crackle();
    }
    if (kind !== 'fire') {
      const bp = ctx.createBiquadFilter(); bp.type = 'bandpass'; bp.frequency.value = 480; bp.Q.value = 0.7;
      const g = ctx.createGain(); g.gain.value = 0.5;
      const lfo = ctx.createOscillator(); lfo.frequency.value = 0.07;
      const lf = ctx.createGain(); lf.gain.value = 260; lfo.connect(lf).connect(bp.frequency);
      const lg = ctx.createGain(); lg.gain.value = 0.3; lfo.connect(lg).connect(g.gain);
      lfo.start();
      const src = noise(); src.playbackRate.value = 1.7;
      src.connect(bp).connect(g).connect(master);
    }
    audio = { ctx, kind, timers, master };
    // Browsers only let sound start after a click or key press on the page itself.
    if (ctx.state !== 'running') {
      const kick = () => { if (audio && audio.ctx === ctx) ctx.resume().catch(() => {}); };
      window.addEventListener('pointerdown', kick, { capture: true, passive: true, once: true });
      window.addEventListener('keydown', kick, { capture: true, passive: true, once: true });
    }
  }
  function stopSound() {
    if (!audio) return;
    for (const t of audio.timers) clearTimeout(t);
    try { audio.ctx.close(); } catch (e) {}
    audio = null;
  }

  /* ------------------------------------------------------------------ journal */

  function bumpJournal(change, announce) {
    safe(() => api.storage.local.get({ journal: null, lastEnter: {} }, (got) => {
      if (api.runtime.lastError) return;
      const j = CF.journal.normalize(got.journal);
      change(j, got);
      const fresh = CF.journal.settle(j);
      safe(() => api.storage.local.set({ journal: j, lastEnter: got.lastEnter }));
      if (announce) announce(got);
      fresh.slice(0, 2).forEach((d, i) => setTimeout(() => toast('Journal: ' + d.title), 1200 + i * 1500));
    }));
  }
  function countVisit() {
    if (visitCounted) return;
    visitCounted = true;
    const now = new Date();
    const day = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0');
    let greet = false;
    bumpJournal((j, got) => {
      j.pages++;
      if (theme) {
        j.sites[theme.id] = (j.sites[theme.id] || 0) + 1;
        const lastT = got.lastEnter[theme.id] || 0;
        if (Date.now() - lastT > 30 * 60 * 1000) { greet = true; got.lastEnter[theme.id] = Date.now(); }
      }
      if (j.lastDay !== day) {
        const y = new Date(now.getTime() - 864e5);
        const yd = y.getFullYear() + '-' + String(y.getMonth() + 1).padStart(2, '0') + '-' + String(y.getDate()).padStart(2, '0');
        j.streak = j.lastDay === yd ? j.streak + 1 : 1;
        j.bestStreak = Math.max(j.bestStreak, j.streak);
        j.days++; j.lastDay = day;
      }
      if (now.getHours() === 3) j.witching++;
    }, () => { if (greet && level >= 2 && theme) card(theme.enter, theme.title); });
  }

  /* ------------------------------------------------------------------ wiring */

  safe(() => api.runtime.onMessage.addListener((msg, sender, reply) => {
    if (!msg || typeof msg !== 'object') return;
    if (msg.type === 'cf-status') {
      reply({
        host: host.replace(/^www\./, ''), active, reason,
        protectedPage: !!reason && reason.startsWith('protected'),
        theme: theme ? theme.name : null, mode, labelCount: marked.size
      });
    } else if (msg.type === 'cf-summon') {
      reply({ ok: runEvent(msg.kind || 'random'), active, busy: eventBusy, still: reduceMotion.matches });
    }
  }));

  safe(() => api.storage.onChanged.addListener((changes, area) => {
    if (area !== 'sync') return;
    let touched = false;
    for (const k in changes) if (k in DEFAULTS) { settings[k] = changes[k].newValue === undefined ? DEFAULTS[k] : changes[k].newValue; touched = true; }
    if (touched) evaluate();
  }));

  document.addEventListener('visibilitychange', () => { if (active) syncSound(); else stopSound(); });
  window.addEventListener('popstate', () => setTimeout(() => { if (location.href !== lastHref) onUrlChange(); }, 0));
  window.addEventListener('hashchange', () => { if (location.href !== lastHref) onUrlChange(); });
  window.addEventListener('pageshow', (e) => { if (e.persisted) evaluate(); });

  function boot() {
    safe(() => api.runtime.sendMessage({ type: 'cf-ping' }, () => void api.runtime.lastError));
    evaluate();
    if (document.readyState === 'loading') {
      // Colour the page as early as we safely can, then finish once the document is parsed.
      const early = new MutationObserver(() => { if (document.body) { early.disconnect(); if (active) apply(); } });
      early.observe(html, { childList: true });
      document.addEventListener('DOMContentLoaded', () => { early.disconnect(); evaluate(); }, { once: true });
    }
    window.addEventListener('load', () => { if (active) { apply(); } }, { once: true });
    // Stylesheets may land after our first look; re-check light/dark a few times early on.
    let early2 = 0;
    const poll = setInterval(() => {
      if (++early2 > 14 || dead) return clearInterval(poll);
      if (active && detectMode().mode !== mode) apply();
    }, 250);
    startTicker();
  }

  safe(() => api.storage.sync.get(DEFAULTS, (got) => {
    if (!api.runtime.lastError && got) settings = Object.assign({}, DEFAULTS, got);
    boot();
  }));
})();
