'use strict';
const api = globalThis.chrome || globalThis.browser;
const $ = (id) => document.getElementById(id);
let blocklist = [];

function clean(v) {
  v = String(v || '').trim().toLowerCase();
  try { if (/^[a-z]+:\/\//.test(v)) v = new URL(v).hostname; } catch (e) {}
  v = v.replace(/^www\./, '').replace(/[\/?#].*$/, '').replace(/:\d+$/, '');
  return /^[a-z0-9.-]+$/.test(v) && v.includes('.') || v === 'localhost' ? v : '';
}
function render() {
  const ul = $('list');
  ul.textContent = '';
  for (const h of blocklist) {
    const li = document.createElement('li');
    const s = document.createElement('span'); s.textContent = h;
    const b = document.createElement('button'); b.type = 'button'; b.textContent = 'Remove';
    b.addEventListener('click', () => { blocklist = blocklist.filter((x) => x !== h); api.storage.sync.set({ blocklist }); render(); });
    li.append(s, b); ul.appendChild(li);
  }
  $('empty').hidden = blocklist.length > 0;
}
api.storage.sync.get({ blocklist: [] }, (g) => { blocklist = (g && g.blocklist) || []; render(); });
api.storage.onChanged.addListener((c, area) => { if (area === 'sync' && c.blocklist) { blocklist = c.blocklist.newValue || []; render(); } });
$('addForm').addEventListener('submit', (e) => {
  e.preventDefault();
  const h = clean($('addInput').value);
  if (!h) { $('addInput').select(); return; }
  if (!blocklist.includes(h)) { blocklist = blocklist.concat(h).sort(); api.storage.sync.set({ blocklist }); }
  $('addInput').value = '';
  render();
});
$('resetJournal').addEventListener('click', () => {
  if (!confirm('Erase every journal entry and counter?')) return;
  api.storage.local.remove(['journal', 'lastEnter'], () => { $('resetMsg').textContent = 'The pages are blank again.'; });
});
