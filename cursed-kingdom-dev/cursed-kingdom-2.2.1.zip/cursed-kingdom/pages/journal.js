'use strict';
const api = globalThis.chrome || globalThis.browser;
const J = globalThis.__CF.journal;
const fmt = (n) => Number(n || 0).toLocaleString();

function render(raw) {
  const j = J.normalize(raw);
  const stats = document.getElementById('stats');
  stats.textContent = '';
  const events = Object.values(j.events).reduce((a, b) => a + (b || 0), 0);
  for (const [n, label] of [[j.pages, 'cursed pages'], [j.days, 'days in the kingdom'], [j.bestStreak, 'best streak (days)'], [events, 'omens witnessed']]) {
    const d = document.createElement('div'); d.className = 'stat';
    const b = document.createElement('b'); b.textContent = fmt(n);
    d.append(b, document.createTextNode(label)); stats.appendChild(d);
  }
  const grid = document.getElementById('grid');
  grid.textContent = '';
  const defs = J.defs();
  let done = 0;
  const rows = defs.map((d) => ({ d, v: d.get(j), ok: d.get(j) >= d.goal }));
  rows.sort((a, b) => (b.ok - a.ok) || (b.v / b.d.goal - a.v / a.d.goal));
  for (const { d, v, ok } of rows) {
    if (ok) done++;
    const el = document.createElement('div'); el.className = 'ach' + (ok ? ' done' : '');
    const ic = document.createElement('div'); ic.className = 'ic'; ic.textContent = d.icon;
    const t = document.createElement('div'); t.className = 't'; t.textContent = d.title;
    const bar = document.createElement('div'); bar.className = 'bar';
    const i = document.createElement('i'); i.style.width = Math.min(100, Math.round(100 * v / d.goal)) + '%'; bar.appendChild(i);
    const n = document.createElement('div'); n.className = 'n';
    const when = j.unlocked[d.id];
    n.textContent = ok ? 'Done' + (when ? ' on ' + new Date(when).toLocaleDateString() : '') : fmt(Math.min(v, d.goal)) + ' of ' + fmt(d.goal);
    el.append(ic, t, bar, n); grid.appendChild(el);
  }
  document.getElementById('count').textContent = done + ' of ' + defs.length;
}
const load = () => api.storage.local.get({ journal: null }, (g) => render(g && g.journal));
load();
api.storage.onChanged.addListener((c, area) => { if (area === 'local' && c.journal) load(); });
