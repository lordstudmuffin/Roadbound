'use strict';
const api = globalThis.chrome || globalThis.browser;
const DEFAULTS = { enabled: true, intensity: 60, labels: true, fog: false, events: true, sound: false, soundKind: 'both', volume: 35, flip: true, fonts: true, scene: true, blocklist: [], darken: {} };
const $ = (id) => document.getElementById(id);
let settings = Object.assign({}, DEFAULTS);
let tabId = null;
let page = null; // status reported by the page script, or null where the extension cannot run

const REASONS = {
  'money-or-identity-site': 'a bank, payment or sign-in site',
  'government-or-bank-domain': 'a government or bank address',
  'hostname-looks-sensitive': 'its address looks like banking, payment or sign-in',
  'address-looks-like-login-or-payment': 'the address looks like a login, account or checkout page',
  'sign-in-page': 'a sign-in page',
  'password-or-card-field': 'a password or card form is showing'
};

function save(patch) {
  Object.assign(settings, patch);
  api.storage.sync.set(patch, () => setTimeout(refreshStatus, 250));
}

function levelName(v) { return v <= 33 ? 'Subtle' : v <= 66 ? 'Haunted' : 'Full curse'; }

function render() {
  $('enabled').checked = !!settings.enabled;
  $('intensity').value = settings.intensity;
  $('intensityOut').textContent = levelName(settings.intensity);
  $('sound').checked = !!settings.sound;
  $('soundKind').value = settings.soundKind;
  $('soundKindRow').hidden = !settings.sound;
  $('volumeRow').hidden = !settings.sound;
  $('volume').value = settings.volume;
  $('flip').checked = settings.flip !== false;
  $('labels').checked = !!settings.labels;
  $('events').checked = !!settings.events;
  $('fog').checked = !!settings.fog;
  $('fonts').checked = settings.fonts !== false;
  $('scene').checked = settings.scene !== false;

  const host = page && page.host;
  $('siteName').textContent = host || 'This page';
  const blocked = host && (settings.blocklist || []).some((e) => host === e || host.endsWith('.' + e));
  const prot = page && page.protectedPage;
  $('site').checked = !!host && !blocked && !prot;
  $('site').disabled = !host || prot || !settings.enabled;
  $('siteHint').textContent = !host ? 'Not available on this page'
    : prot ? 'Protected page. Always left alone.'
    : blocked ? 'Spared. On your blocklist.' : 'Cursed';
  $('darken').value = (host && settings.darken && settings.darken[host]) || 'auto';
  $('darkenRow').hidden = !host;

  let s;
  if (!page) s = 'The curse has not reached this tab. Reload it. (Browser pages, the extension store and new tabs stay off limits.)';
  else if (!settings.enabled) s = 'The curse sleeps. Everything looks normal.';
  else if (prot) s = 'Standing down: ' + (REASONS[String(page.reason).replace('protected:', '')] || 'this looks like a protected page') + '.';
  else if (blocked) s = 'You spared this site.';
  else if (page.active) s = page.theme ? 'You are in ' + page.theme + '.' : 'This land is cursed.';
  else s = 'Reload the page to cast the curse.';
  $('status').textContent = s;
}

function refreshStatus() {
  if (tabId == null) { page = null; render(); return; }
  try {
    api.tabs.sendMessage(tabId, { type: 'cf-status' }, (res) => {
      void api.runtime.lastError;
      page = res || null;
      render();
    });
  } catch (e) { page = null; render(); }
}

api.storage.sync.get(DEFAULTS, (got) => {
  settings = Object.assign({}, DEFAULTS, got || {});
  render();
  api.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    tabId = tabs && tabs[0] ? tabs[0].id : null;
    refreshStatus();
  });
});

$('enabled').addEventListener('change', (e) => save({ enabled: e.target.checked }));
$('intensity').addEventListener('input', (e) => { $('intensityOut').textContent = levelName(+e.target.value); });
$('intensity').addEventListener('change', (e) => save({ intensity: +e.target.value }));
$('sound').addEventListener('change', (e) => { save({ sound: e.target.checked }); render(); });
$('soundKind').addEventListener('change', (e) => save({ soundKind: e.target.value }));
$('volume').addEventListener('change', (e) => save({ volume: +e.target.value }));
for (const id of ['labels', 'events', 'fog', 'flip', 'fonts', 'scene']) $(id).addEventListener('change', (e) => save({ [id]: e.target.checked }));

$('site').addEventListener('change', (e) => {
  if (!page || !page.host) return;
  const list = (settings.blocklist || []).filter((x) => !(page.host === x || page.host.endsWith('.' + x)));
  if (!e.target.checked) list.push(page.host);
  save({ blocklist: list });
  render();
});

$('darken').addEventListener('change', (e) => {
  if (!page || !page.host) return;
  const d = Object.assign({}, settings.darken || {});
  if (e.target.value === 'auto') delete d[page.host]; else d[page.host] = e.target.value;
  save({ darken: d });
});

for (const b of document.querySelectorAll('[data-ev]')) {
  b.addEventListener('click', () => {
    if (tabId == null) return;
    const say = (t) => { $('summonMsg').textContent = t; };
    try {
      api.tabs.sendMessage(tabId, { type: 'cf-summon', kind: b.dataset.ev }, (r) => {
        void api.runtime.lastError;
        say(!r ? 'Nothing answers on this page.' : r.ok ? 'It comes… close this popup to watch.' : r.still ? 'Your system asks for reduced motion, so events stay still.' : r.busy ? 'One omen at a time.' : 'The curse is not active on this page.');
      });
    } catch (e) { say('Nothing answers on this page.'); }
  });
}
